from fastapi import FastAPI
from app.routers.filme_router import router

app = FastAPI(title="API de Filmes")

app.include_router(router)

@app.get("/")
def home():
    return {"Message": "FastAPI + MongoDB + Docker rodando em camadas!"}